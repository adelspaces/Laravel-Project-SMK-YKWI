console.log(typeof swal);
